import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class P2Wins here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class P2Wins extends Buttons
{
    /**
     * Act - do whatever the P2Wins wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
