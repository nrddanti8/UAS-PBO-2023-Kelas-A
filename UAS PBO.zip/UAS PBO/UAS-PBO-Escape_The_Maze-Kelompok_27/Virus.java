import greenfoot.*;

public class Virus extends Obstacles
{
    private int moveCounter = 0;
    
    public Virus()
    {
        GreenfootImage myImage = getImage();
        int myNewHeight = (int) myImage.getHeight() / 10;
        int myNewWidth = (int) myImage.getWidth() / 10;
        myImage.scale(myNewWidth, myNewHeight);
    }
    public void act()
    {
        moveAround();
    }

    private void moveAround()
    {
        moveCounter++;

        if (moveCounter >= 5) {
            turn(Greenfoot.getRandomNumber(91) - 45); 
            moveCounter = 0; 
        }

        int x = getX();
        int y = getY();
        int worldWidth = getWorld().getWidth();
        int worldHeight = getWorld().getHeight();

        int nextX = (int) (x + Math.cos(Math.toRadians(getRotation())));
        int nextY = (int) (y + Math.sin(Math.toRadians(getRotation())));

        if (nextX > 0 && nextX < worldWidth && nextY > 0 && nextY < worldHeight) {
            move(1);
        }
    }
}
